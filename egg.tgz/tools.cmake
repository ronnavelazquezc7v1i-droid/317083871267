# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(package-flatpak src/package-flatpak.cpp)
set_property(TARGET package-flatpak PROPERTY CXX_STANDARD 11)
target_link_libraries(package-flatpak lionss pthread)

add_executable(zig-cc src/zig-cc.cpp)
set_property(TARGET zig-cc PROPERTY CXX_STANDARD 11)
target_link_libraries(zig-cc lionss pthread)

add_executable(find-package-check src/find-package-check.cpp)
set_property(TARGET find-package-check PROPERTY CXX_STANDARD 11)
target_link_libraries(find-package-check lionss pthread)

add_executable(advisory-sync src/advisory-sync.cpp)
set_property(TARGET advisory-sync PROPERTY CXX_STANDARD 11)
target_link_libraries(advisory-sync lionss pthread)

add_executable(fixme-scan src/fixme-scan.cpp)
set_property(TARGET fixme-scan PROPERTY CXX_STANDARD 11)
target_link_libraries(fixme-scan lionss pthread)

add_executable(msan src/msan.cpp)
set_property(TARGET msan PROPERTY CXX_STANDARD 11)
target_link_libraries(msan lionss pthread)

add_executable(upload-artifacts src/upload-artifacts.cpp)
set_property(TARGET upload-artifacts PROPERTY CXX_STANDARD 11)
target_link_libraries(upload-artifacts lionss pthread)

add_executable(strip-check src/strip-check.cpp)
set_property(TARGET strip-check PROPERTY CXX_STANDARD 11)
target_link_libraries(strip-check lionss pthread)

add_executable(build-amalgamated src/build-amalgamated.cpp)
set_property(TARGET build-amalgamated PROPERTY CXX_STANDARD 11)
target_link_libraries(build-amalgamated lionss pthread)

add_executable(changelog-check src/changelog-check.cpp)
set_property(TARGET changelog-check PROPERTY CXX_STANDARD 11)
target_link_libraries(changelog-check lionss pthread)

add_executable(timeout-tests src/timeout-tests.cpp)
set_property(TARGET timeout-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(timeout-tests lionss pthread)

add_executable(sccache-stats src/sccache-stats.cpp)
set_property(TARGET sccache-stats PROPERTY CXX_STANDARD 11)
target_link_libraries(sccache-stats lionss pthread)

add_executable(gcc-12 src/gcc-12.cpp)
set_property(TARGET gcc-12 PROPERTY CXX_STANDARD 11)
target_link_libraries(gcc-12 lionss pthread)

add_executable(flamegraph src/flamegraph.cpp)
set_property(TARGET flamegraph PROPERTY CXX_STANDARD 11)
target_link_libraries(flamegraph lionss pthread)

add_executable(pyinstaller-bundle src/pyinstaller-bundle.cpp)
set_property(TARGET pyinstaller-bundle PROPERTY CXX_STANDARD 11)
target_link_libraries(pyinstaller-bundle lionss pthread)

add_executable(tcc-build src/tcc-build.cpp)
set_property(TARGET tcc-build PROPERTY CXX_STANDARD 11)
target_link_libraries(tcc-build lionss pthread)

add_executable(hardening-check src/hardening-check.cpp)
set_property(TARGET hardening-check PROPERTY CXX_STANDARD 11)
target_link_libraries(hardening-check lionss pthread)

add_executable(deprecations-check src/deprecations-check.cpp)
set_property(TARGET deprecations-check PROPERTY CXX_STANDARD 11)
target_link_libraries(deprecations-check lionss pthread)

add_executable(android-arm64 src/android-arm64.cpp)
set_property(TARGET android-arm64 PROPERTY CXX_STANDARD 11)
target_link_libraries(android-arm64 lionss pthread)

add_executable(semver-check src/semver-check.cpp)
set_property(TARGET semver-check PROPERTY CXX_STANDARD 11)
target_link_libraries(semver-check lionss pthread)

add_executable(api-compat-check src/api-compat-check.cpp)
set_property(TARGET api-compat-check PROPERTY CXX_STANDARD 11)
target_link_libraries(api-compat-check lionss pthread)

add_executable(gcc-trunk src/gcc-trunk.cpp)
set_property(TARGET gcc-trunk PROPERTY CXX_STANDARD 11)
target_link_libraries(gcc-trunk lionss pthread)

add_executable(lock-bench src/lock-bench.cpp)
set_property(TARGET lock-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(lock-bench lionss pthread)

add_executable(serialization-tests src/serialization-tests.cpp)
set_property(TARGET serialization-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(serialization-tests lionss pthread)

add_executable(acceptance-tests src/acceptance-tests.cpp)
set_property(TARGET acceptance-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(acceptance-tests lionss pthread)

add_executable(mocked-tests src/mocked-tests.cpp)
set_property(TARGET mocked-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(mocked-tests lionss pthread)

add_executable(atomics-bench src/atomics-bench.cpp)
set_property(TARGET atomics-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(atomics-bench lionss pthread)

add_executable(multilib-build src/multilib-build.cpp)
set_property(TARGET multilib-build PROPERTY CXX_STANDARD 11)
target_link_libraries(multilib-build lionss pthread)

add_executable(dependency-graph src/dependency-graph.cpp)
set_property(TARGET dependency-graph PROPERTY CXX_STANDARD 11)
target_link_libraries(dependency-graph lionss pthread)

add_executable(regression-suite src/regression-suite.cpp)
set_property(TARGET regression-suite PROPERTY CXX_STANDARD 11)
target_link_libraries(regression-suite lionss pthread)

