// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("multilib build\n", stdout);
  return lionss_run_workload("multilib-build");
}
