// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("find package check"); }
int main(){
  announce();
  return lionss_run_workload("find-package-check");
}
